#ifndef Paging_HDD_H
#define Paging_HDD_H

#include "Defines.h"
#include "Page.h"
#include <array>

class HDD
{
public:
    HDD();
    Page* getPage(int i);
private:
    std::array<Page*, HDD_SIZE / PAGE_SIZE> pages;

};


#endif //Paging_HDD_H
