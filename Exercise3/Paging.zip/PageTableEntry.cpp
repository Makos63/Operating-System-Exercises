#include "PageTableEntry.h"

PageTableEntry::PageTableEntry()
{
    presentbit = false;
    modifiziertbit = false;
    referenziertbit = false;
    pageFrameNr = -1;
}

void PageTableEntry::setPageFrameNr(int i)
{
    pageFrameNr = i;
}

int PageTableEntry::getPageFrameNr()
{
    return pageFrameNr;
}

void PageTableEntry::setPresentbit(bool presentbit)
{
    this->presentbit = presentbit;
}

bool PageTableEntry::isPresentbit() const
{
    return presentbit;
}

void PageTableEntry::setReferenziertbit(bool referenziertbit)
{
    this->referenziertbit = referenziertbit;
}

bool PageTableEntry::isReferenziertbit() const
{
    return referenziertbit;
}

void PageTableEntry::setModifiziertbit(bool modifiziertbit)
{
    this->modifiziertbit = modifiziertbit;
}

bool PageTableEntry::isModifiziertbit() const
{
    return modifiziertbit;
}

void PageTableEntry::setAllBitsFalse()
{
    presentbit = false;
    modifiziertbit = false;
    referenziertbit = false;
}

/*PageTableEntry::PageTableEntry(const PageTableEntry& orig)
{
}

PageTableEntry::~PageTableEntry()
{
}*/