#ifndef Paging_MMU_H
#define Paging_MMU_H

#include "Defines.h"
#include "OS.h"
#include "RAM.h"
#include "PageTable.h"
#include "PageTableEntry.h"

class MMU {
public:
    MMU();

    int getPhysicalAddress(int process, int virtualAddress);

    int getMeasurement();

private:
    PageTable *currentPageTable;
    RAM *ram;
    OS *os;

};


#endif //Paging_MMU_H
