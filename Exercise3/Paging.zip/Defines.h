#ifndef Paging_DEFINES_H
#define Paging_DEFINES_H

#define RAM_SIZE 1024
//Mindestens VIRTUAL_MEEMORY_SIZE * PROCESS_NR
#define HDD_SIZE 16384

#define VIRTUAL_MEMORY_SIZE 4096

//#define PAGE_SIZE 512
#define PAGE_SIZE 256
#define PROCESS_NR 4

#define READ_PROBABILITY 60
#define WRITE_PROBABILITY 90
#define SLEEP_TIME 100 //in ms

#endif //Paging_DEFINES_H
