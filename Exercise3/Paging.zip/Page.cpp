#include "Page.h"

Page::Page()
{
}

Page::Page(int nr)
{
    for (int i = 0; i < pageEntry.size(); i++)
        pageEntry[i] = (unsigned char) nr;
}

unsigned char Page::getPageEntry(int position)
{
    return pageEntry[position];
}

void Page::setPageEntry(int val,int position) {
    pageEntry[position]=val;
}

/*Page::Page(const Page& orig)
{
}

Page::~Page()
{
}*/