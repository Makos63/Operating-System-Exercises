#include "OS.h"

OS::OS() {
    ram = RAM::getInstance();
    pagesEmpty = RAM_SIZE / PAGE_SIZE;
    pageErrorCounter = 0;
}

PageTable *OS::createPageTable(int process) {
    PageTable *pt = new PageTable();
    ram->writePageTable(process, pt);
    return pt;
}

void OS::managePageTables(int process, int page) {
    if (pagesEmpty <= 0 || 0 == (pagesEmpty--)) {
        std::cout << "Aktuelle Prozess: " <<
                  process << " Seitenfehler! " << std::endl;

        ++pageErrorCounter;
        ram->pagingFIFO(process, page);

    } else
        ram->writePage(process, page);
}

int OS::getMeasurement() {
    return pageErrorCounter;
}
