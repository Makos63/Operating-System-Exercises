#ifndef Paging_CPU_H
#define Paging_CPU_H


#include "Defines.h"
#include "MMU.h"
#include "RAM.h"
#include <iostream>
#include <iomanip> //setw

class CPU {
public:
    CPU();

    void makeStep();

    void read();

    void write();

    void swapProcess();

    void generateVirtualAddress();

    void printMeasurement();

private:
    RAM *ram;
    MMU *mmu;
    int currentProcess, currentVirtualAddress, operationsNr;//read+write
};


#endif //Paging_CPU_H
