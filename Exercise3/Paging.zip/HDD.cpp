#include "HDD.h"

HDD::HDD()
{
    for (int i = 0; i < pages.size(); i++)
        pages[i] = new Page(i / (VIRTUAL_MEMORY_SIZE / PAGE_SIZE));
    //(pages auf der Festplatte)/(pages pro Prozess)
    //--> alle Pages des Prozesses bekommen die gleiche Beschreibung
}

Page* HDD::getPage(int i)
{
    return pages[i];
}
