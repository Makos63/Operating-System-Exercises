#ifndef Paging_OS_H
#define Paging_OS_H

#include "PageTable.h"
#include "RAM.h"

class OS
{
public:
    OS();
    PageTable* createPageTable(int process);
    void managePageTables(int process, int page);
    int getMeasurement();
private:
    RAM* ram;
    int pagesEmpty;
    int pageErrorCounter;
};


#endif //Paging_OS_H
