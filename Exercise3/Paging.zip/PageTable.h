#ifndef Paging_PAGETABLE_H
#define Paging_PAGETABLE_H

#include <array>
#include "Defines.h"
#include "PageTableEntry.h"

class PageTable
{
public:
    PageTable();
    PageTableEntry* getPageTableEntry(int i);
    int getSize();
private:
    std::array<PageTableEntry*, VIRTUAL_MEMORY_SIZE / PAGE_SIZE> entry;

};


#endif //Paging_PAGETABLE_H
