#include <thread>
#include <chrono>
#include "CPU.h"
#include "MMU.h"

CPU::CPU() {
    ram = RAM::getInstance();
    mmu = new MMU();
    currentProcess = 0;
    currentVirtualAddress = -1;
    operationsNr = 0;
}

void CPU::makeStep() {
    int random_number = random() % 100;
    if (random_number < READ_PROBABILITY) {
        operationsNr++;
        read();
    } else if (random_number < WRITE_PROBABILITY) {
        operationsNr++;
        write();
    } else {
        swapProcess();
    }
}

void CPU::read() {
    generateVirtualAddress();
    int currentPhysicalAdress = mmu->getPhysicalAddress(currentProcess, currentVirtualAddress);
    ram->getPageTable(currentProcess)->getPageTableEntry(currentPhysicalAdress / PAGE_SIZE)->setReferenziertbit(true);

    std::cout << "Aktuelle Prozess: " << currentProcess
              << " Lesen Adresse Virt.: " << currentVirtualAddress
              << " Lesen Adresse Phys.: " << currentPhysicalAdress
              << " Wert: " << ram->getDataFromAddress(currentPhysicalAdress) << std::endl;


    if (ram->getDataFromAddress(currentPhysicalAdress) != currentProcess) {
        std::cout << "Seite des falschen Prozesses ausgelesen!" << std::endl;
        exit(0);
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(SLEEP_TIME));
}

void CPU::write() {
    generateVirtualAddress();
    int currentPhysicalAddress = mmu->getPhysicalAddress(currentProcess, currentVirtualAddress);
    ram->getPageTable(currentProcess)->getPageTableEntry(currentPhysicalAddress / PAGE_SIZE)->setReferenziertbit(true);
    ram->getPageTable(currentProcess)->getPageTableEntry(currentPhysicalAddress / PAGE_SIZE)->setModifiziertbit(true);


    std::cout << "Aktuelle Prozess: " << currentProcess
              << " Schreiben Adresse Virt.: " << currentVirtualAddress
              << " Schreiben Adresse Phys.: " << currentPhysicalAddress
              << " Wert: " << currentProcess << std::endl;


    //man kann das mit festen Wert für ein currentProcess
    ram->writeValue(currentPhysicalAddress,currentProcess);

    if (ram->getDataFromAddress(currentPhysicalAddress) != currentProcess) {
        std::cout << "Seite des falschen Prozesses beschrieben!" << std::endl;
        exit(0);
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(SLEEP_TIME));

}

void CPU::swapProcess() {
    currentProcess = (currentProcess + random() % (PROCESS_NR - 1) + 1) % PROCESS_NR;
    std::this_thread::sleep_for(std::chrono::milliseconds(SLEEP_TIME));
}

void CPU::generateVirtualAddress() {
    currentVirtualAddress = random() % VIRTUAL_MEMORY_SIZE;
}

void CPU::printMeasurement() {
    std::cout << std::setw(30) << "Anzahl der Seitenfehler: " << mmu->getMeasurement() << " (";
    std::cout << std::setprecision(3) << (float) mmu->getMeasurement() / (float) operationsNr * 100;
    std::cout << "% der read/write Operationen)" << std::endl;
}
