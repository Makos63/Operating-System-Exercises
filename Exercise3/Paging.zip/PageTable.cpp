#include "PageTable.h"

PageTable::PageTable()
{
    for (int i = 0; i < entry.size(); i++)
        entry[i] = new PageTableEntry();
}

PageTableEntry* PageTable::getPageTableEntry(int i)
{
    return entry[i];
}

int PageTable::getSize()
{
    return entry.size();
}