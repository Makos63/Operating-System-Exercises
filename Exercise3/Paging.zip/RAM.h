#ifndef Paging_RAM_H
#define Paging_RAM_H

#include <array>
#include <vector>
#include <utility> //pair
#include <iostream>
#include "Defines.h"
#include "Page.h"
#include "PageTable.h"
#include "HDD.h"

class RAM {
public:
    static RAM *getInstance();

    PageTable *getPageTable(int i);

    void writePageTable(int process, PageTable *pt);

    void writePage(int process, int page);

    void writeValue(int address, int procID);

    unsigned int getDataFromAddress(int adress);

    void pagingFIFO(int process, int page);

private:
    RAM();

    static RAM *instance;
    HDD *hdd;
    std::array<Page *, RAM_SIZE / PAGE_SIZE> pages;
    std::array<PageTable *, PROCESS_NR> pageTables;
    int pagePointer;

};


#endif //Paging_RAM_H
