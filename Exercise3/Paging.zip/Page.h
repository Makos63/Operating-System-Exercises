#ifndef Paging_PAGE_H
#define Paging_PAGE_H

#include <array>
#include <iostream>
#include "Defines.h"

class Page
{
public:
    Page();
    Page(int nr);
    unsigned char getPageEntry(int position);
    void setPageEntry(int val,int position);
private:
    std::array<unsigned char, PAGE_SIZE> pageEntry;

};


#endif //Paging_PAGE_H
