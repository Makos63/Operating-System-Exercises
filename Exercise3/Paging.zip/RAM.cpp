#include "RAM.h"

RAM *RAM::instance;

RAM::RAM() {
    for (int i = 0; i < pages.size(); i++)
        pages[i] = new Page();
    hdd = new HDD();
    pagePointer = -1;
}

RAM *RAM::getInstance() {
    if (nullptr == instance) {
        instance = new RAM();
    }
    return instance;
}

PageTable *RAM::getPageTable(int i) {
    return pageTables[i];
}

void RAM::writePageTable(int process, PageTable *pt) {
    pageTables[process] = pt;
}

void RAM::writePage(int process, int page) {
    pages[(++pagePointer) % (RAM_SIZE / PAGE_SIZE)]
            = hdd->getPage(process * (VIRTUAL_MEMORY_SIZE / PAGE_SIZE) + page);
    pageTables[process]->getPageTableEntry(page)->setPresentbit(true);
    pageTables[process]->getPageTableEntry(page)->setPageFrameNr(pagePointer);
}

void RAM::writeValue(int address, int procID) {
    //procID is Value;
    int page = address / PAGE_SIZE;
    int position = address % PAGE_SIZE;
    pages[page]->setPageEntry(procID,position);
}

unsigned int RAM::getDataFromAddress(int address) {
    int page = address / PAGE_SIZE;
    int position = address % PAGE_SIZE;
    return (unsigned int) pages[page]->getPageEntry(position);
}

void RAM::pagingFIFO(int process, int page) {
    pagePointer = (pagePointer + 1) % (RAM_SIZE / PAGE_SIZE);

    for (int i = 0; i < pageTables.size(); i++) {
        if (pageTables[i] == nullptr) continue;

        for (int j = 0; j < pageTables[i]->getSize(); j++) {

            if (pageTables[i]->getPageTableEntry(j)->getPageFrameNr() == pagePointer
                && pageTables[i]->getPageTableEntry(j)->isPresentbit()) {

                pageTables[i]->getPageTableEntry(j)->setAllBitsFalse();

                pages[pagePointer] = hdd->getPage(process * (VIRTUAL_MEMORY_SIZE / PAGE_SIZE) + page);

                pageTables[process]->getPageTableEntry(page)->setPresentbit(true);
                pageTables[process]->getPageTableEntry(page)->setPageFrameNr(pagePointer);

            }
        }
    }
}

