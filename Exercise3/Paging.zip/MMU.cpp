#include "MMU.h"

MMU::MMU() {
    ram = RAM::getInstance();
    os = new OS();
}

int MMU::getPhysicalAddress(int process, int virtualAddress) {
    currentPageTable = ram->getPageTable(process);
    if (nullptr == currentPageTable) {
        currentPageTable = os->createPageTable(process);
    }

    int page = virtualAddress / PAGE_SIZE;
    int position = virtualAddress % PAGE_SIZE;

    if (!currentPageTable->getPageTableEntry(page)->isPresentbit()) {
        os->managePageTables(process, page);
    }

    int pageFrameNr = currentPageTable->getPageTableEntry(page)->getPageFrameNr();

    return pageFrameNr * PAGE_SIZE + position;
}


int MMU::getMeasurement() {
    return os->getMeasurement();
}
