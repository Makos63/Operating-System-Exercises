#include <iostream>
#include <iomanip>
#include "Defines.h"
#include "CPU.h"

using namespace std;

int main(int argc, char **argv) {

        CPU cpu;
        cout << "Random Adressgenerator" << endl;
        cout << "FIFO Seitenersetzungsalgorithmus" << endl;


        int steps;
        cout << endl << "Wie viele Steps? ";
        cin >> steps;

        for (int i = 0; i < steps; i++) {
            cpu.makeStep();
        }


        cout << "Messung:" << endl;
        cout << setw(30) << left << "Anzahl der Prozesse: " << PROCESS_NR << endl;
        cout << setw(30) << "Anzahl der Schritte: " << steps << endl;
        cpu.printMeasurement();

    return 0;
}