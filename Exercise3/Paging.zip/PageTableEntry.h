#ifndef Paging_PAGETABLEENTRY_H
#define Paging_PAGETABLEENTRY_H

#include "Defines.h"

class PageTableEntry
{
public:
    PageTableEntry();
    void setPageFrameNr(int i);
    int getPageFrameNr();
    void setPresentbit(bool presentbit);
    bool isPresentbit() const;
    void setReferenziertbit(bool referenziertbit);
    bool isReferenziertbit() const;
    void setModifiziertbit(bool modifiziertbit);
    bool isModifiziertbit() const;
    void setAllBitsFalse();
    //PageTableEntry(const PageTableEntry& orig);
    //virtual ~PageTableEntry();
private:
    bool presentbit;
    bool modifiziertbit;
    bool referenziertbit;
    int pageFrameNr;
};


#endif //Paging_PAGETABLEENTRY_H
