//
// Created by Maciej Krzysztoń on 27.11.19.
//

#include "Scheduler.h"

Scheduler::Scheduler() {
    quantum = 1;
}

Process *Scheduler::next(Process *currentProcess) {
    if (currentProcess != nullptr) {
        if (currentProcess->getDelta() >= quantum) {
            currentProcess->resetDelta();
            if (activeProcesses.size() > 0) {
                activeProcesses.push_back(currentProcess);
                currentProcess = activeProcesses.front();
                activeProcesses.erase(activeProcesses.begin());
            }
        }
    } else {
        if(activeProcesses.size() > 0) {
            currentProcess = activeProcesses.front();
            activeProcesses.erase(activeProcesses.begin());
        }
    }
    return currentProcess;
}

void Scheduler::unblock() {
    //if(blockedProcesses.size() > 0) {
        Process* p = blockedProcesses.front();//holt das objekt
        blockedProcesses.erase(blockedProcesses.begin()); //loescht durch itr
        activeProcesses.push_back(p);
    //}
}

void Scheduler::block(Process *currentProcess) {
    if(blockedProcesses.size() > 0 && activeProcesses.size() == 0) {
        activeProcesses.push_back(currentProcess);
    } else{
        blockedProcesses.push_back(currentProcess);
    }
}

void Scheduler::add(Process *newProcess) {
    activeProcesses.push_back(newProcess);
}




int Scheduler::getQuantum() const {
    return quantum;
}

void Scheduler::setQuantum(int quantum) {
    Scheduler::quantum = quantum;
}

const std::vector<Process *> &Scheduler::getReadyProcesses() const {
    return activeProcesses;
}

void Scheduler::setReadyProcesses(const std::vector<Process *> &readyProcesses) {
    Scheduler::activeProcesses = readyProcesses;
}

const std::vector<Process *> &Scheduler::getBlockedProcesses() const {
    return blockedProcesses;
}

void Scheduler::setBlockedProcesses(const std::vector<Process*> &blockedProcesses) {
    Scheduler::blockedProcesses = blockedProcesses;
}