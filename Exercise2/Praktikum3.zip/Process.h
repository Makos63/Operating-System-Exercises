//
// Created by Maciej Krzysztoń on 27.11.19.
//

#ifndef BS2_PROCESS_H
#define BS2_PROCESS_H

#include <string>
#include <vector>

class Process {
public:
    Process(int pid, int ppid, int priority, int runtimeStart, std::vector<std::pair<std::string,std::string>> commands);
    std::pair<std::string,std::string> getCommand(int pc);

    void addCycle();
    void resetDelta();


    int getPid() const;

    void setPid(int pid);

    int getPpid() const;

    void setPpid(int ppid);

    int getPriority() const;

    void setPriority(int priority);

    int getRuntime() const;

    void setRuntime(int runtime);

    int getDelta() const;

    void setDelta(int delta);

    int getRuntimeStart() const;

    void setRuntimeStart(int runtimeStart);

    int getCycles() const;

private:
    int pid;
    int ppid;
    int priority;
    int runtime;
    int delta;
    int cycles;
    int runtimeStart;

    std::vector<std::pair<std::string,std::string>> commandPairs;
};


#endif //BS2_PROCESS_H
