#include <iostream>
#include "CPU.h"
int main() {

    CPU cpu(new Scheduler());
    Scheduler sched;
    while(true) {
        std::string input, command, parameter;
        std::cout << std::endl << "choose:\n" << "[S]tep n\n"
             << "[U]nblock\n" << "[P]rint\n"
             << "[Q]uit" << std::endl;
        getline(std::cin, input);
        std::stringstream ss(input);
        getline(ss, command, ' ');
        getline(ss, parameter, '\n');
        if(command == "S" || command == "Step") {
            if(parameter.size() <= 0) {
                parameter = "1";
            }
            cpu.simulate(stoi(parameter));
        } else if(command == "U" || command == "Unblock") {
            cpu.unblockProcess();
        } else if(command == "P" || command == "Print") {
            cpu.printAll();
        } else if(command == "Q" || command == "Quit") {
            std::cout << "Average cycles per process: " << cpu.getAverageCyclesPerProcess() << std::endl;
            exit(0);
        } else {
            std::cout << "Unknown command!" << std::endl;
        }

    }
    return 0;
}