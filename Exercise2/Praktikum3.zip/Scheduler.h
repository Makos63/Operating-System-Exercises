//
// Created by Maciej Krzysztoń on 27.11.19.
//

#ifndef BS2_SCHEDULER_H
#define BS2_SCHEDULER_H

#include "Process.h"

class Scheduler {
public:
    Scheduler();
    Process* next(Process* currentProcess);
    void block(Process* currentProcess);
    void unblock();
    void add(Process* newProcess);

    int getQuantum() const;
    void setQuantum(int quantum);

    const std::vector<Process *> &getReadyProcesses() const;
    void setReadyProcesses(const std::vector<Process *> &readyProcesses);
    const std::vector<Process *> &getBlockedProcesses() const;
    void setBlockedProcesses(const std::vector<Process *> &blockedProcesses);

//private:
    int quantum;
    std::vector<Process*> activeProcesses;
    std::vector<Process*> blockedProcesses;

};


#endif //BS2_SCHEDULER_H
