//
// Created by Maciej Krzysztoń on 27.11.19.
//

#include "CPU.h"

CPU::CPU() {

}

CPU::CPU(Scheduler *myScheduler)
        : currentProcess(nullptr), myScheduler(myScheduler), pc(0), pCycles(0), cpuTime(0), ppid(0),
          reg(0) {
    createProcess("init");
    currentProcess = myScheduler->next(currentProcess);

}


void CPU::simulate(int steps) {

    Scheduler scheduler;
    int Quantum = scheduler.getQuantum();

    for (int i = 0; i < steps; ++i) {
        if (i >= Quantum ) {
            std::pair<std::string, std::string> commandPair = currentProcess->getCommand(pc++);
            currentProcess->addCycle();
            execute(commandPair);
            ++pCycles;
            continue;
        }

        /*if (currentProcess != nullptr) {
            std::pair<std::string, std::string> commandPair = currentProcess->getCommand(pc++);
            currentProcess->addCycle();
            execute(commandPair);
            ++pCycles;
            save();
            currentProcess = myScheduler->next(currentProcess);
            restore();
            ++cpuTime;*/
            if (i >= Quantum) {//fehler beim mehr als quantum

            std::pair<std::string, std::string> tmpPair;
            tmpPair.first = "B";
            tmpPair.second = "";
            execute(tmpPair);


            //scheduler.activeProcesses.insert(scheduler.activeProcesses.begin(),currentProcess);


            //}

        }

        save();
        currentProcess = myScheduler->next(currentProcess);
        restore();
        ++cpuTime;
    }
}

void CPU::unblockProcess() {
    myScheduler->unblock();
}

void CPU::printAll() {
    std::cout << "****************************************************************" << std::endl;
    std::cout << "The current system state is as follows" << std::endl;
    std::cout << "****************************************************************" << std::endl;
    std::cout << "CURRENT TIME: " << cpuTime << std::endl;
    std::cout << "RUNNING PROCESS:" << std::endl;
    std::cout << std::left << std::setw(10) << "pid" << std::setw(10) << "ppid" << std::setw(10) << "priority"
              << std::setw(10) << "value" << std::setw(15)
              << "start time" << std::setw(25) << "CPU time used so far" << std::endl;
    if (currentProcess != nullptr) {
        std::cout << std::left << std::setw(10) << currentProcess->getPid() << std::setw(10)
                  << currentProcess->getPpid() << std::setw(10)
                  << currentProcess->getPriority() << std::setw(10) << reg << std::setw(15)
                  << currentProcess->getRuntimeStart()
                  << std::setw(25) << currentProcess->getCycles() << std::endl;
    }
    std::cout << "BLOCKED PROCESSES:" << std::endl;
    std::cout << std::left << std::setw(10) << "pid" << std::setw(10) << "ppid" << std::setw(10) << "priority"
              << std::setw(10) << "value" << std::setw(15)
              << "start time" << std::setw(25) << "CPU time used so far" << std::endl;
    std::vector<Process *> blockedProcesses = myScheduler->getBlockedProcesses();
    for (Process *process : blockedProcesses) {
        std::cout << std::left << std::setw(10) << process->getPid() << std::setw(10) << process->getPpid()
                  << std::setw(10)
                  << process->getPriority() << std::setw(10) << processMap.at(process->getPid()).reg << std::setw(15)
                  << process->getRuntimeStart() << std::setw(25) << process->getCycles() << std::endl;
    }
    std::cout << "PROCESSES READY TO EXECUTE:" << std::endl;
    std::cout << std::left << std::setw(10) << "pid" << std::setw(10) << "ppid" << std::setw(10) << "priority"
              << std::setw(10) << "value" << std::setw(15)
              << "start time" << std::setw(25) << "CPU time used so far" << std::endl;
    std::vector<Process *> readyProcesses = myScheduler->getReadyProcesses();
    for (Process *process : readyProcesses) {
        std::cout << std::left << std::setw(10) << process->getPid() << std::setw(10) << process->getPpid()
                  << std::setw(10)
                  << process->getPriority() << std::setw(10) << processMap.at(process->getPid()).reg << std::setw(15)
                  << process->getRuntimeStart() << std::setw(25) << process->getCycles() << std::endl;
    }
}


void CPU::createProcess(std::string filename) {
    std::ifstream file;
    std::stringstream stream;
    std::string line, str1, str2 = " ";


    file.open(filename);

    std::vector<std::pair<std::string, std::string>> tmpCommandPairs;

    if (!file) {
        throw "could not be opened";
    }
    while (getline(file, line)) {
        stream.clear();
        stream << line;

        getline(stream, str1, ' ');
        getline(stream, str2);

        tmpCommandPairs.push_back(make_pair(str1, str2));
        stream.clear();
    }
    //file.close();
    Process *newProcess = new Process(ppid, (currentProcess == nullptr ? 0 : currentProcess->getPid()), 0, cpuTime,
                                      tmpCommandPairs);
    ppid++;
    ProcessRegs pRegs;

    pRegs.reg = 0;
    pRegs.pc = 0;

    myScheduler->add(newProcess);
    processMap[newProcess->getPid()] = pRegs;
}


int CPU::getAverageCyclesPerProcess() {
    return pCycles / ppid;
}

void CPU::execute(std::pair<std::string, std::string> command) {
    currentProcess->addCycle();
    if (command.first == "D") {
        def(stoi(command.second));
    } else if (command.first == "A") {
        add(stoi(command.second));
    } else if (command.first == "S") {
        sub(stoi(command.second));
    } else if (command.first == "B") {

        blockProcess();
        schedule();
    } else if (command.first == "X") {
        terminateProcess();
        schedule();
    } else if (command.first == "R") {
        createProcess(command.second);
        schedule();
    }


}

void CPU::blockProcess() {
    for (int i = 0; i < myScheduler->getBlockedProcesses().size(); i++) {


        if (currentProcess->getPid() == myScheduler->getBlockedProcesses().at(i)->getPid()) {
            break;

        }
    }
    save();
    myScheduler->block(currentProcess);
    currentProcess = nullptr;
}

void CPU::schedule() {
    save();
    currentProcess = myScheduler->next(currentProcess);
    restore();
}

void CPU::add(int i) {
    reg += i;
}

void CPU::sub(int i) {
    reg -= i;
}

void CPU::def(int i) {
    reg = i;
}


void CPU::terminateProcess() {
    std::cout << "Process with PID: " << currentProcess->getPid() << "has terminated" << std::endl;
    delete currentProcess;
    currentProcess = nullptr;
}

void CPU::save() {
    if (currentProcess != nullptr) {
        ProcessRegs newReg;
        newReg.pc = pc;
        newReg.reg = reg;
        processMap[currentProcess->getPid()] = newReg;
    }
}

void CPU::restore() {
    if (currentProcess != nullptr) {
        reg = processMap.at(currentProcess->getPid()).reg;
        pc = processMap.at(currentProcess->getPid()).pc;
    }
}


