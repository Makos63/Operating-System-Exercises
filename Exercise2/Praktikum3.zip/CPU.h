//
// Created by Maciej Krzysztoń on 27.11.19.
//

#ifndef BS2_CPU_H
#define BS2_CPU_H

#include <iostream>
#include <fstream>
#include <map>
#include <time.h>
#include <string>
#include <iostream>
#include <sstream>
#include <iomanip>

#include "Scheduler.h"
#include "Process.h"

struct ProcessRegs{
    int reg;
    int pc;
};

class CPU {

public:
    CPU();
    CPU(Scheduler* aScheduler);

    void simulate(int steps);
    void unblockProcess();
    void printAll();
    int getAverageCyclesPerProcess();

private:
    int pc;
    int reg;
    int ppid;
    int cpuTime;
    int pCycles;

    Process* currentProcess;
    Scheduler* myScheduler;
    std::map<int,ProcessRegs> processMap;

    void execute(std::pair<std::string,std::string> command);
    void add(int);
    void sub(int);
    void def(int);
    void blockProcess();
    void terminateProcess();
    void save();
    void restore();

    void createProcess(std::string);
    void schedule();


};


#endif //BS2_CPU_H
