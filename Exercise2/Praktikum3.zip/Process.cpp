//
// Created by Maciej Krzysztoń on 27.11.19.
//

#include "Process.h"


Process::Process(int pid, int ppid, int priority, int runtimeStart, std::vector<std::pair<std::string,std::string>> commands)
        :pid(pid),ppid(ppid),priority(priority),runtimeStart(runtimeStart),runtime(0),delta(0),commandPairs(commands) {

}


std::pair<std::string, std::string> Process::getCommand(int pc) {
    return commandPairs.at(pc);
}

int Process::getPid() const {
    return pid;
}

void Process::setPid(int pid) {
    Process::pid = pid;
}

int Process::getPpid() const {
    return ppid;
}

void Process::setPpid(int ppid) {
    Process::ppid = ppid;
}

int Process::getPriority() const {
    return priority;
}

void Process::setPriority(int priority) {
    Process::priority = priority;
}

int Process::getRuntime() const {
    return runtime;
}

void Process::setRuntime(int runtime) {
    Process::runtime = runtime;
}

int Process::getDelta() const {
    return delta;
}

void Process::setDelta(int delta) {
    Process::delta = delta;
}

int Process::getRuntimeStart() const {
    return runtimeStart;
}

void Process::setRuntimeStart(int runtimeStart) {
    Process::runtimeStart = runtimeStart;
}

void Process::addCycle() {
    ++delta;
    ++runtime;
}

void Process::resetDelta() {
    delta = 0;
}

int Process::getCycles() const {
    return runtime;//cycles
}
